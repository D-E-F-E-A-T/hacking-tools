<?php
// DB details 
$hostname	= 'localhost'; // Your Host Name
$database	= 'mydatabase'; // DataBase Name
$username	= 'user'; // Database Username
$password	= 'password'; // Password

// Acess details
$adminuser = 'admin';
$adminpass = 'admin';

// Config
$logsperpage	= 100; // how many logs to show per page?
?>